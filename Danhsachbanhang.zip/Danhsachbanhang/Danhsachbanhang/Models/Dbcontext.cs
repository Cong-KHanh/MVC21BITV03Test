﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace Danhsachbanhang.Models
{
    

    public class ApplicationDbContext : Dbcontext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<Car> Cars { get; set; }
        public DbSet<Sale> Sales { get; set; }
    }

    public class Dbcontext
    {
        private readonly DbContextOptions<ApplicationDbContext> options;

        public Dbcontext(DbContextOptions<ApplicationDbContext> options)
        {
            this.options = options;
        }
    }
}
