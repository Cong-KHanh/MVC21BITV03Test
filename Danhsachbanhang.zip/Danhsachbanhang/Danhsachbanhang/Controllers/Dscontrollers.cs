﻿using Danhsachbanhang.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Danhsachbanhang.Controllers
{
    public class Dscontrollers
    {

    }
    public class SalesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SalesController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var data = await _context.Sales
                .Include(s => s.Car)
                .Include(s => s.Customer)
                .Select(s => new
                {
                    CustomerId = s.Customer.Id,
                    CustomerName = s.Customer.Name,
                    BirthDate = s.Customer.BirthDate,
                    CarMake = s.Car.Make,
                    CarModel = s.Car.Model
                })
                .ToListAsync();

            return View(data);
        }
    }
}
